# VYRA AI — APK-ready Android project

This project wraps the supplied VYRA HTML prototype screens in an Android WebView and provides a mobile launcher/dashboard.

## Build
Open this folder in Android Studio and let Gradle sync, then Build > Build APK(s).

The project includes the original `code.html` screens as local assets. External fonts/CDN resources used by those screens may require internet access; the launcher itself is local.

## Important
This is an APK-ready **frontend prototype**, not yet the full AI backend, live game vision, overlay engine, or automatic clipping system.
